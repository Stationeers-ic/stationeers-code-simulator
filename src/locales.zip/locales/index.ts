import en from "./en/index.json"
import ru from "./ru/index.json"


export default {
	en,
	ru
}

